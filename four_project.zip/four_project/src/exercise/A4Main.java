package exercise;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * I Juan Naranjo 000895164 certify that this is my original work. I have not
 * used any uncited external resources and I have not shared my work with anyone else.
 * I did not use ChatGPT or any other AI-based tool.
 */

/**
 * Performance Comparison and Answers:
 *
 * 1. Timing Results:
 *    +-----------------------------+-------------------+-----------+
 *    | Method                      | Time to Build (ms)| Checksum  |
 *    +-----------------------------+-------------------+-----------+
 *    | ArrayList (sort after add)  | 1,782             | 933,405   |
 *    | Primitive Array (iSort)     | 2,198             | 933,405   |
 *    | SortedLinkedList            | 366               | 933,405   |
 *    | SortedArray                 | 134               | 933,405   |
 *    +-----------------------------+-------------------+-----------+
 *
 * 2. Performance:
 *    - SortedLinkedList took 366 ms andSortedArray took 134 ms.
 *    - SortedArray is faster because it uses an ArrayList O(1) access
 *    - SortedLinkedList requires O(n) for each insertion.
 *    - The arrays contains the memory that is going to be used for the calculations
 *     while the Linked List contains the points to different locations and addresses
 *
 * 3. When to Use SortedLinkedList Over SortedArray:
 *    - Use SortedLinkedList when:
 *      Common insertions are used and the sorted order is important
 *      The Size of the list can change
 *    - Use SortedArray when:
 *      Random access to elements
 *      Memory usage its important and required
 *
 * 4. Why SortedLinkedList Outperforms ArrayList with Built-in Sort:
 *    - ArrayList sorts the entire list after each insertion
 *    - SortedLinkedList uses insertion sort during each insertion
 *    - SortedLinkedList is faster because it goes to the position of the insertion point
 *     while ArrayList performs a full sort after each addition.
 *
 * 5. Why iSort() is Slower Than SortedLinkedList:
 *    - isort() uses insertion sort in the primitive array that use the shifting elements after each insertion
 *    that cause the O(n²)
 *    - SortedLinkedList use the pointers to add elements that makes it more efficient \
 */


public class A4Main {
    /**
     *
     * @param args (unused)
     */
    public static void main(String[] args) {
        runPartA();
        runPartB();
    }

    /**
     * Validate that an array of Strings is sorted
     *
     * @param array array that might or might not be sorted
     * @return a 6 digit checksum if sorted, -1 if not sorted.
     */

    //source : https://www.geeksforgeeks.org/java-string-compareto-method-with-examples/
    public static int ckSumSorted(String[] array) {
        if (array.length == 0)
            return 1;
        int sum = 0;
        int i =0;
        String prev = array[0];
        for(String str: array) {
            if (str.compareTo(prev) < 0)
                return -1;
            i++;
            sum += str.hashCode() * i;
            prev = str;
        }
        return Math.abs(sum % 1000_000);
    }

    /**
     * Simple validation of data structures
     */
    public static void runPartA() {
        System.out.println("\n\nPart A --- \n");
        SortedLinkedList<String> linkedList = new SortedLinkedList<>();
        SortedArray<String> sortedArray = new SortedArray<>();

        String[] names = {"Bob", "Carol", "Aaron", "Alex", "Zaphod"};

        System.out.println("Initial Array = " + Arrays.toString(names));
        System.out.printf("Initial Array sorted = %,d\n", ckSumSorted(names));

        for (String name : names) {
            linkedList.add(name);
            sortedArray.add(name);
        }

        System.out.println("LinkedList: " + linkedList);
        String[] sl = {linkedList.get(0), linkedList.get(1), linkedList.get(2), linkedList.get(3), linkedList.get(4)};
        System.out.println(Arrays.toString(sl));
        System.out.printf("LinkedList ckSumSorted = %,d\n\n", ckSumSorted(sl));
        System.out.println("SortedArray: " + sortedArray);

        String[] sa = {sortedArray.get(0), sortedArray.get(1), sortedArray.get(2), sortedArray.get(3), sortedArray.get(4)};
        System.out.println(Arrays.toString(sa));
        System.out.printf("SortedArray ckSumSorted = %,d\n", ckSumSorted(sa));

        // Remove all names from linked list
        for (String name : names) {
            linkedList.remove(name);
        }
        linkedList.remove("Karen");
        System.out.println("LinkedList after removals: " + linkedList);

        // Additional data type test <Integer> for example

        SortedLinkedList<Integer> integerList = new SortedLinkedList<>();
        integerList.add(5);
        integerList.add(3);
        integerList.add(8);
        integerList.add(1);
        System.out.println("Integer List" + integerList);
        // Remove the element
        integerList.remove(5);
        System.out.println("Integer List after the removal:" + integerList);
    }

    /**
     * Insertion sort
     *
     * @param array - an array of strings.
     * @param n - elements
     */

    // source : https://www.geeksforgeeks.org/insertion-sort-algorithm/
    public static void iSort(String[] array, int n) {
        for (int i = 1; i < n; i++) {
            String key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j].compareTo(key) > 0) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }

    /**
     * Part B
     * Performance testing for ArrayList, LinkedList and SortedArray
     */
    public static void runPartB() {
        ArrayList<String> bnames = new ArrayList<>();
        long startTime;

        System.out.println("\n\nPart B --- \n");
        // Read from file - do not change
        startTime = System.currentTimeMillis();
        try (Scanner scanner = new Scanner(new File("src/exercise/bnames.txt"))) {
            while (scanner.hasNextLine()) {
                bnames.add(scanner.nextLine().trim());
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found.");
            return;
        }
        long endTime = System.currentTimeMillis();
        String[] sa = new String[bnames.size()];
        for (int i = 0; i < bnames.size(); i++)
            sa[i] = bnames.get(i);
        System.out.printf("bnames.txt ckSumSorted = %,d\n", ckSumSorted(sa));
        System.out.printf("Read file bnames.txt: %,d items read in %,d ms\n\n",
                bnames.size(), (endTime - startTime));

        // ArrayList Add
        ArrayList<String> sortedAL = new ArrayList<>();
        startTime = System.currentTimeMillis();
        for (String name : bnames) {
            sortedAL.add(name);
            sortedAL.sort((a, b) -> (a.compareTo(b))); // Sort after each add
        }
        endTime = System.currentTimeMillis();
        System.out.printf("ArrayList added %,d items\n", sortedAL.size());
        for (int i = 0; i < sortedAL.size(); i++)
            sa[i] = sortedAL.get(i);
        System.out.printf("ArrayList ckSumSorted = %,d\n", ckSumSorted(sa));
        System.out.printf("Time to build sorted ArrayList, sort after each .add() %,d ms\n\n", endTime - startTime);

        // Primitive Array with iSort
        String[] primitiveArray = new String[bnames.size()]; // Store the txt in an primitive array
        startTime = System.currentTimeMillis(); // time
        for (int i = 0; i < bnames.size(); i++) {
            primitiveArray[i] = bnames.get(i);
            iSort(primitiveArray, i + 1); // Sort only the first i+1 elements
        }
        endTime = System.currentTimeMillis();
        System.out.printf("Primitive Array added %,d items\n", primitiveArray.length);
        System.out.printf("Primitive Array ckSumSorted = %,d\n", ckSumSorted(primitiveArray));
        System.out.printf("Time to build sorted Primitive Array, sort after each insert %,d ms\n\n", endTime - startTime);

        // SortedLinkedList
        SortedLinkedList<String> sortedLinkedList = new SortedLinkedList<>();
        startTime = System.currentTimeMillis();
        for (String name : bnames) {
            sortedLinkedList.add(name);
        }
        endTime = System.currentTimeMillis();
        System.out.printf("SortedLinkedList added %,d items\n", bnames.size());
        String[] sll = new String[bnames.size()];
        for (int i = 0; i < bnames.size(); i++) {
            sll[i] = sortedLinkedList.get(i);
        }
        System.out.printf("SortedLinkedList ckSumSorted = %,d\n", ckSumSorted(sll));
        System.out.printf("Time to build SortedLinkedList %,d ms\n\n", endTime - startTime);

        // SortedArray
        SortedArray<String> sortedArray = new SortedArray<>();
        startTime = System.currentTimeMillis();
        for (String name : bnames) {
            sortedArray.add(name);
        }
        endTime = System.currentTimeMillis();
        System.out.printf("SortedArray added %,d items\n", bnames.size());
        String[] sarr = new String[bnames.size()];
        for (int i = 0; i < bnames.size(); i++) {
            sarr[i] = sortedArray.get(i);
        }
        System.out.printf("SortedArray ckSumSorted = %,d\n", ckSumSorted(sarr));
        System.out.printf("Time to build SortedArray %,d ms\n\n", endTime - startTime);
    }
}