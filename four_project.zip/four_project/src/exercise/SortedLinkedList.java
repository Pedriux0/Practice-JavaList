package exercise;

/**
 * Generic Linked List class that always keeps the elements in order
 *
 * @author mark.yendt
 */
public class SortedLinkedList<T extends Comparable> {
    /**
     * The Node class stores a list element and a reference to the next node.
     */
    private final class Node<T extends Comparable> {
        T value;
        Node next;

        /**
         * Constructor.
         *
         * @param val The element to store in the node.
         * @param n   The reference to the successor node.
         */
        Node(T val, Node n) {
            value = val;
            next = n;
        }

        /**
         * Constructor.
         *
         * @param val The element to store in the node.
         */
        Node(T val) {
            // Call the other (sister) constructor.
            this(val, null);
        }
    }

    private Node head;  // list head

    /**
     * Constructor.
     */
    public SortedLinkedList() {
        head  = null;
    }

    /**
     * The isEmpty method checks to see if the list is empty.
     *
     * @return true if list is empty, false otherwise.
     */


    public boolean isEmpty() {
        return head == null;
    }

    /**
     * Return the item from the list at the given index.
	 *
     * @param index the elements index
     * @return the item at the given index
     */

    //source : https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/LinkedList.html
    public T get(int index) {
        Node current = head; // Set current node as head
        for (int i = 0; i< index ; i++){ // Loop to pass the current elements to the next one
            current = current.next;
        }
        return (T) current.value; // Return the current value
    }

    /**
     * The size method returns the length of the list.
     *
     * @return The number of elements in the list.
     */
    public int size() {
        int count = 0;
        Node p = head;
        while (p != null) {
            // There is an element at p
            count++;
            p = p.next;
        }
        return count;
    }

    /**
     * The add method adds an element at a position.
     *
     * @param element The element to add to the list in sorted order.
     */

    //source : https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/LinkedList.html
    public void add(T element) {
        Node newNode = new Node(element);
        if (head == null || head.value.compareTo(element) > 0) {
            // Insert at the beginning of the list
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            // Insert after current
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    /**
     * The toString method computes the string representation of the list.
     *
     * @return The string form of the list.
     */
    public String toString()
    {
        String str = "[";

        // Use p to walk down the linked list
        Node p = head;
        while (p != null) {
            str += p.value + ",";
            p = p.next;
        }

        return str.substring(0,str.length()-1) + "]";
    }

    /**
     * The remove method removes an element.
     *
     * @param element The element to remove.
     * @return true if the remove succeeded, false otherwise.
     */

    //source : https://www.geeksforgeeks.org/deletion-in-linked-list/
    public boolean remove(T element) {
        if(head == null){//List is empty
            return false;
        }
        // Remove head
        if(head.value.equals(element)){
            head = head.next;
            return true;
        }
        Node current = head;
        while(current.next != null){
            if(current.next.value.equals(element)){
                current.next = current.next.next ;// Pass the same element
                return true;
            }
            current = current.next;
        }
        return false;
    }
}